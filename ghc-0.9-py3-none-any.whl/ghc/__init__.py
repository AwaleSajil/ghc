from ghc._command import run_command, run_with_pipe
from ghc.get_tc import get_t_c
from ghc.l_ghc_cf import l_ghc_cf
